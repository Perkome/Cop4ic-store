# Cop4ic Clothing Static Website

This is a simple static website template for the Cop4ic clothing brand.

## How to Use

### Shopify Buy Button Integration
1. Log in to your Shopify Admin.
2. Go to **Buy Button > Create Buy Button**.
3. Choose the product and generate embed code.
4. Replace the `<div id="product-component-1"></div>` with the embed code.
5. Paste the `<script>` at the bottom of `index.html`.

### Customize
- Replace product images and descriptions in `index.html`.
- Modify styles in `style.css`.

### Deploy
- You can host this on Netlify, Vercel, or GitHub Pages.

## Contact
For questions or help: support@cop4ic.com
